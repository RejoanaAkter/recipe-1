
export const Routes = {
    home: '/',
    about: '/about',
    recipes: '/recipes',
    createRecipe:'/createRecipe'
}