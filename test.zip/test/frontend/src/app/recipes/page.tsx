

import RecipesPage from "@/containers/recipes"

const RecipesRoute = () => {

    return (
        <>
            <RecipesPage />
        </>
    )
}

export default RecipesRoute