

import CreateRecipesPage from "@/containers/create-recipe"

const RecipesRoute = () => {

    return (
        <>
            <CreateRecipesPage />
        </>
    )
}

export default RecipesRoute