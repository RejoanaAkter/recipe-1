import HomeScreen from "@/containers/home";
import NavBar from "@/containers/navbar";

export default function Home() {

  

  return (
    <div>     
    <HomeScreen />
    </div>
  );

}
