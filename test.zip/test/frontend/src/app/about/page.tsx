import AboutScreen from "@/containers/about"


const AboutRoute=()=>{

    return(
        <>
        <AboutScreen />
        </>
    )
}

export default AboutRoute