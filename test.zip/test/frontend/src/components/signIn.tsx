'use client'


import { Routes } from "@/config/routes";
import { useRouter } from "next/navigation";
import { useState } from "react";

const SignIn = ({ setShowModal, setIsLoginView }) => {
    const router = useRouter();
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        address: '',
        password: '',
        about: '',  
        image: null,
    });
    const [formError, setFormError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleInputChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'image') {
            setFormData((prev) => ({ ...prev, image: files[0] }));
        } else {
            setFormData((prev) => ({ ...prev, [name]: value }));
        }
    };


    const handleSubmit = async () => {
        setIsSubmitting(true);
        setFormError('');

        try {
            const data = new FormData();
            data.append('name', formData.name);
            data.append('email', formData.email);
            data.append('address', formData.address);
            data.append('password', formData.password);
            data.append('about', formData.about);
            if (formData.image) {
                data.append('image', formData.image);
            }

            const res = await fetch('http://localhost:8000/users/user', {
                method: 'POST',
                body: data,
            });

            const contentType = res.headers.get('content-type') || '';
            if (!contentType.includes('application/json')) {
                throw new Error('Invalid response from server');
            }

            const result = await res.json();

            if (!res.ok) {
                throw new Error(result.message || 'Failed to create user');
            }

            setShowModal(false);
            router.push(`${Routes.createRecipe}?userId=${result.userId}`);
            // router.push(Routes.createRecipe);
        } catch (err) {
            setFormError(err.message);
        } finally {
            setIsSubmitting(false);
        }
    };


    return (

            <div className="fixed inset-0 bg-white/10 backdrop-blur-[0.5px] flex items-center justify-center z-50">
  <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
                <h2 className="text-lg font-bold mb-4">Create User</h2>
                <input
                    type="text"
                    name="name"
                    placeholder="Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                    required
                />
                <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                    required
                />
                <input
                    type="text"
                    name="address"
                    placeholder="Address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                    required
                />
                <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                    required
                />

                <textarea
                    name="about"
                    placeholder="About / Description"
                    value={formData.about}
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                    rows={3}
                />
                <input
                    type="file"
                    name="image"
                    accept="image/*"
                    onChange={handleInputChange}
                    className="w-full p-2 border mb-2"
                />
                {formData.image && (
                    <img
                        src={URL.createObjectURL(formData.image)}
                        alt="Preview"
                        className="w-20 h-20 object-cover rounded mb-2"
                    />
                )}


                {formError && <p className="text-red-500">{formError}</p>}
                <div className="flex justify-end space-x-2">
                    <button
                        type="button"
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 border rounded"
                    >
                        Cancel
                    </button>
                    <button
                        type="button"
                        disabled={isSubmitting}
                        onClick={handleSubmit}
                        className="bg-blue-500 text-white px-4 py-2 rounded"
                    >
                        {isSubmitting ? 'Submitting...' : 'Create & Continue'}
                    </button>
                </div>
                <p className="mt-4 text-center">
                    Already have an account?{' '}
                    <button
                        onClick={() => {
                            setIsLoginView(true);
                            setFormError('');
                        }}
                        className="text-blue-600 underline"
                    >
                        Login
                    </button>
                </p>
                </div></div>
           
    )
}

export default SignIn;