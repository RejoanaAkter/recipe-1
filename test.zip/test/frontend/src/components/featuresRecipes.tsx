'use client'
import React, { useEffect, useState } from 'react';
import ItemCard from './item-card';
import 'swiper/css';
import useRecipes from './useRecipes';
import CategoryListModal from './view-category';
import RecipeDetailsModal from './recipe-details-modal';

function FeaturesRecipes() {

    const { recipes } = useRecipes()
  const [selectedId, setSelectedId] = useState(null);

    return (

        <div className="grid grid-cols-8">
            <div className="col-span-1"></div>
            <div className="col-span-6">
            
                <div className='grid 2xl:grid-cols-6 xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 md:grid-cols-3 grid-cols-1'>
                    {recipes?.slice(0, 6).map((recipe, index) => (
                        <div key={index} >
                            <ItemCard item={recipe}  onSelect={setSelectedId} />
                        </div>
                    ))}
            </div> 
            </div>
            <div className="col-span-1"></div>

       
             {selectedId && (
               <RecipeDetailsModal
                 recipeId={selectedId}
                 onClose={() => setSelectedId(null)}
               />
             )}
        </div>
    );
}

export default FeaturesRecipes;
