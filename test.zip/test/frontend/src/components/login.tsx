'use client'

import { Routes } from "@/config/routes";
import { useRouter } from "next/navigation";
import { useState } from "react";

const LogIn = ({ setShowModal, setIsLoginView }) => {
  const router = useRouter();

  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleLoginChange = (e) => {
    const { name, value } = e.target;
    setLoginData((prev) => ({ ...prev, [name]: value }));
  };

  const handleLoginSubmit = async () => {
    setIsLoggingIn(true);
    setLoginError('');

    try {
      const res = await fetch('http://localhost:8000/users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      });

      const result = await res.json();

      if (!res.ok) {
        throw new Error(result.message || 'Login failed');
      }

      setShowModal(false);
      //   router.push(Routes.createRecipe);
      router.push(`${Routes.createRecipe}?userId=${result.userId}`);
    } catch (err) {
      debugger
      setLoginError(err.message);
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-white/10 backdrop-blur-[0.5px] flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
        <>
        <h2 className="text-lg font-bold mb-4">Login</h2>
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={loginData.email}
          onChange={handleLoginChange}
          className="w-full p-2 border mb-2"
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={loginData.password}
          onChange={handleLoginChange}
          className="w-full p-2 border mb-2"
          required
        />
        {loginError && <p className="text-red-500">{loginError}</p>}
        <div className="flex justify-end space-x-2">
          <button
            onClick={() => setShowModal(false)}
            className="px-4 py-2 border rounded"
          >
            Cancel
          </button>
          <button
            onClick={handleLoginSubmit}
            disabled={isLoggingIn}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            {isLoggingIn ? 'Logging in...' : 'Login'}
          </button>
        </div>
        <p className="mt-4 text-center">
          Don't have an account?{' '}
          <button
            onClick={() => {
              setIsLoginView(false);
              setLoginError('');
            }}
            className="text-blue-600 underline"
          >
            Sign Up
          </button>
        </p>
        </>
      </div>
    </div>
  )
}

export default LogIn; 