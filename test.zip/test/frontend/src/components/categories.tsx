'use client';

import Image from 'next/image';
import React, { useState } from 'react';
import ItemCard from './item-card';
import useCategories from './useCategories';
import useRecipesByCategory from './useRecipesBycategory';
import getImageUrl from '@/settings/utils';
import { FaPlateWheat } from 'react-icons/fa6';

interface Category {
  _id: string;
  name: string;
  imageUrl: string;
}

interface Recipe {
  id: string;
  title: string;
}

const CategoryList: React.FC = () => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);

  const { categories, loading: loadingCategories, error: categoryError } = useCategories();
  const { recipes, loading: loadingRecipes, error: recipeError, fadeIn } = useRecipesByCategory(selectedCategoryId);


  return (
    <div className="py-6 px-4">

      <div className="flex gap-2">
        <p className="mt-1"> <FaPlateWheat /></p>
        <h1 className="text-lg text-md text-gray-700" >Recent Categories</h1>
      </div>

      <div className="flex">
        <div className="w-1/5"></div>
        <div className="w-3/5">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
            {categories?.slice(0, 5).map((cat: Category) => (
              <div
                key={cat._id}
                onClick={() => setSelectedCategoryId(cat._id)}
                className={`bg-white rounded-md shadow hover:shadow-md transition p-1 cursor-pointer ${selectedCategoryId === cat._id ? 'ring-2 ring-dg-secondary-accent' : ''
                  }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 relative rounded-full overflow-hidden">
                    <Image src={getImageUrl(cat.imageUrl)} alt={cat.name} fill className="object-cover" />
                  </div>
                  <h3 className="font-medium text-gray-700">{cat.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="w-1/5"></div>
      </div>

      <h2 className="mt-8 text-xl font-semibold">
        Recipes
      </h2>

      {loadingRecipes && <p className="mt-2 animate-pulse">Loading recipes...</p>}
      {!loadingRecipes && recipes.length === 0 && selectedCategoryId && (
        <p className="mt-2 text-gray-500">No recipes found.</p>
      )}

      <div className="flex gap-4 h-auto">
        {recipes.map((recipe: Recipe, index: number) => (
          <div
            key={recipe.id || index}
            style={{
              transitionDelay: `${index * 100}ms`,
            }}
            className={`transition-all duration-500 ease-in-out transform ${fadeIn ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
          >
            <ItemCard item={recipe} onSelect={null} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryList;
