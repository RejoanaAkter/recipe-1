'use client';

import { Routes } from "@/config/routes";
import { useRouter, usePathname } from 'next/navigation';
import { RiHome4Fill } from "react-icons/ri";
import { BiInfoCircle } from "react-icons/bi";
import { GiKnifeFork } from "react-icons/gi";
import { MdOutlineNewspaper } from "react-icons/md";
import { chownSync } from "fs";
import { useEffect } from "react";

const NavBar = () => {
  const router = useRouter();
  const pathname = usePathname();

  const navItems = [
    { name: 'Home', path: Routes.home, icon: <RiHome4Fill /> },
    { name: 'About', path: Routes.about, icon: <BiInfoCircle /> },
    { name: 'Recipes', path: Routes.recipes, icon: <GiKnifeFork /> },
    { name: 'News', path: '/news', icon: <MdOutlineNewspaper /> }
  ];

  const handleNavigate = (path: string) => {
    router.push(path);
  };


  return (
    <>
      <div
        className="flex w-full h-[300px] bg-cover bg-center bg-no-repeat px-8 mt-4 items-center"
        style={{ backgroundImage: "url('/h.jpg')" }}
      >
        <div className="w-2/3 text-white">
          <h1 className="text-[40px] italic font-bold mb-4">Learn Cooking in a yummy way!</h1>
          <p className="text-lg">Over 100,000 food recipes from all over the world. You can try it now!</p>
        </div>
      </div>

      <div className="w-full h-12 flex justify-end text-gray-700 px-8 bg-white">
        <div className="flex gap-6 items-center w-full justify-start">
          {navItems.map((item) => (
            <div
              key={item.name}
              onClick={() => handleNavigate(item.path)}
              className={`text-sm text-slate-600 px-2 py-1 cursor-pointer flex items-center gap-1 cursor-pointer transition  transition-all font-semibold   
                        duration-300 ease-in-out bg-gray-100 rounded-full hover:text-slate-600 hover:border-slate-700 hover:border  
                        ${pathname === item.path ? 'text-lime-800 font-semibold rounded px-2 py-1 bg-aber-200' : ''
                }`}
            >
              <span className="text-lg">{item.icon}</span>
              <span>{item.name}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default NavBar;
