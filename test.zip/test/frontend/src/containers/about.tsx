

const AboutScreen=()=>{

    return(
        <>
        about
        </>
    )
}

export default AboutScreen