'use client'

import React, { useEffect, useState } from 'react';
import HomeCover from './cover';

function HomeScreen() {

  return (
    <div >
      <HomeCover />
    </div>
  );
}

export default HomeScreen
