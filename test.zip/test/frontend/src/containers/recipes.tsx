'use client';

import CategoryCreateModal from '@/components/create-category';
import ItemCard from '@/components/item-card';
import LogIn from '@/components/login';
import RecipeDetailsModal from '@/components/recipe-details-modal';
import SignIn from '@/components/signIn';
import useRecipes from '@/components/useRecipes';
import CategoryListModal from '@/components/view-category';
import React, { useState } from 'react';

function RecipesScreen() {
  const { recipes, error } = useRecipes();
  const [isLoginView, setIsLoginView] = useState(true);
  const [showModal, setShowModal] = useState(false);

  const [showCategoryCreate, setShowCategoryCreate] = useState(false);
  const [showCategoryList, setShowCategoryList] = useState(false);

  const [selectedId, setSelectedId] = useState(null);

  return (
    <div>
      {/* Create Recipe Button */}
      <button
        className="bg-pink-100 text-gray-600 border px-4 py-2 rounded"
        onClick={() => {
          setShowModal(true);
          setIsLoginView(true); // default to login form
        }}
      >
        Create Recipe
      </button>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
            {isLoginView ? (
              <LogIn setShowModal={setShowModal} setIsLoginView={setIsLoginView} />
            ) : (
              <SignIn setShowModal={setShowModal} setIsLoginView={setIsLoginView} />
            )}
          </div>
        </div>
      )}

      {/* Recipes List */}
      <h2 className="mt-6 mb-4 text-2xl font-bold text-center">All Recipes</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {recipes.length === 0 ? (
        <p className="text-center">No recipes found.</p>
      ) : (
        <div className="grid 2xl:grid-cols-6 xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 md:grid-cols-3 grid-cols-1 mx-8 gap-6">
          {recipes?.map((recipe, index) => (
            <ItemCard key={index} item={recipe} onSelect={setSelectedId} />
          ))}
        </div>
      )}


      <div className="flex gap-4 mt-4">
        <button
          className="bg-green-100 text-gray-700 px-4 py-2 border rounded"
          onClick={() => setShowCategoryCreate(true)}
        >
          Add Category
        </button>
        <button
          className="bg-blue-100 text-gray-700 px-4 py-2 border rounded"
          onClick={() => setShowCategoryList(true)}
        >
          View Categories
        </button>
      </div>

      {selectedId && (
        <RecipeDetailsModal
          recipeId={selectedId}
          onClose={() => setSelectedId(null)}
        />
      )}

      {showCategoryCreate && (
        <CategoryCreateModal setShowModal={setShowCategoryCreate} />
      )}
      {showCategoryList && (
        <CategoryListModal setShowModal={setShowCategoryList} />
      )}
    </div>
  );
}

export default RecipesScreen;
