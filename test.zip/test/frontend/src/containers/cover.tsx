import CategoryList from "@/components/categories"
import FeaturesRecipes from "@/components/featuresRecipes"
import { FaPlateWheat } from "react-icons/fa6"


const HomeCover = () => {


    return (
        <div >
            <div>
                <div className="flex gap-2">
                    <p className="mt-1"> <FaPlateWheat /></p>
                    <h1 className="text-lg text-md text-gray-700" >Featured Recipes</h1>
                </div>
                <FeaturesRecipes />
            </div>

            <div className="border-t border-t-slate-400 h-auto mt-4">
                <CategoryList />
            </div>
        </div>
    )
}

export default HomeCover